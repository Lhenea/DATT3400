// Lsystem code by Daniel Shiffman && Barney Codes
//lysystem init
var angle;
var axiom = "F";
var sentence = axiom;
var len = 10;
var rules = {
  "F": [
    { rule: "FF+[+F-F-F]-[-F+F+F]", prob: 0.4 },
    { rule: "[-F+F+F]F[-F+F+F]", prob: 0.3 },
    { rule: "F[-F][+FFF]", prob: 0.2 },
    { rule: "[+FFF]FA", prob: 0.05 },
    { rule: "[-FFF]FB", prob: 0.05 }
  ]
};
var trees = [];
//speech init
var speechRec;
var userSpeech = "";
var sentenceArray = [];
var lastTime = 0;
var lastTime2 = 0;
var interval = 7000;
var interval2 = 5000;
var displayed;
//sounds init
let birds;
let whispers;
//bg img
let bgimg;

function preload(){
  birds = loadSound('assets/birds-short.mp3');
  whispers = loadSound('assets/whispers.mp3');
  bgimg = loadImage('assets/forest.jpg');
}
function setup() {
  createCanvas(600, 400);
  textSize(24);
  
  
 
    //background noise
  noise = new p5.Noise('brown');
  noise.amp(0.01);
  noise.start();
  birds.setVolume(0.5);
  birds.loop();
  whispers.setVolume(0.0);
  whispers.loop();

   // set up voice
  if (typeof p5.SpeechRec === "function") {
    speechRec = new p5.SpeechRec('en-US', gotSpeech);
    speechRec.continuous = true;
    speechRec.interimResults = false;
    speechRec.start();
  } else {
    console.error("p5.SpeechRec not found. Check library import.");
  }
 
  //lysystem
  angle = radians(25);
  
  //words 
  displayed = createP(" ");
  displayed.style('color', 'white');
  displayed.style('font-size', '24px');
  displayed.style('text-align', 'center');
  displayed.style('background-color', 'rgba(0, 0, 0, 0.5)');
  displayed.style('padding', '20px');
  displayed.style('border-radius', '5px');
  displayed.style('box-shadow', '0px 4px 6px rgba(0, 0, 0, 0.2)');
  displayed.style('width', '550px');
  displayed.style('font-family', 'Courier New, monospace');
}

function draw() {
  background(bgimg);

  // Draw all prev trees
  for (let tree of trees) {
    turtle(tree.x, tree.y, tree.sentence);

  }

  //draw the words
  let targ = 0.01;
  let targ2 = 0.1;
  let last = '';
  
  //when words are in...
  if (sentenceArray.length > 0){
    //every 3 seconds
  let current = millis();
  
  if(current - lastTime >= interval2){
    lastTime2 = current;
    targ = 0.01;
    targ2 = 0.1;
    birds.fade(targ, 1);
    whispers.fade(targ2, 1);
 
  }
  //every 7 seconds...

 if(current - lastTime >= interval){
   lastTime = current;
    //find latest entry
    if (sentenceArray.length > 0) {
      let ind = int(random(0,sentenceArray.length));
      last = sentenceArray[ind];
      }
   if (last){
     displayed.html(last);
   }
     targ = 0.5;
    targ2 = 0.0;
   birds.fade(targ, 1);
  whispers.fade(targ2, 1);
   
 }

  }
  
  
}

function generateMultiple(gen) {
  sentence = axiom;
  for (let i = 0; i < gen; i++) {
    generate();
  }
  let x = int(random(20, 580));
  let y = int(random(350, height));
  
  // save tree
  trees.push({ x: x, y: y, sentence: sentence });
  
  turtle(x, y, sentence);
}

function generate() {
  var nextSentence = "";
  for (var i = 0; i < sentence.length; i++) {
    var current = sentence.charAt(i);
    if (current in rules) {
      nextSentence += chooseOne(rules[current]);
    } else {
      nextSentence += current;
    }
  }
  sentence = nextSentence;
}

function chooseOne(ruleSet) {
  let n = random();
  let t = 0;
  for (let i = 0; i < ruleSet.length; i++) {
    t += ruleSet[i].prob;
    if (t > n) return ruleSet[i].rule;
  }
  return ruleSet[0].rule;
}

function turtle(w, y, sentence) {
  resetMatrix();
  translate(w, y);
  stroke(255, 100);
  
  for (var i = 0; i < sentence.length; i++) {
    var current = sentence.charAt(i);
    if (current == "F") {
      stroke("#9ea93f");
      strokeWeight(2);
      line(0, 0, 0, -len);
      translate(0, -len);
    } else if (current == "A") {
      noStroke();
      fill("#FCA17D");
      circle(0, 0, len/2);
    } else if (current == "B") {
      noStroke();
      fill("#E5CEDC");
      circle(0, 0, len/2);
    } else if (current == "+") {
      rotate(angle);
    } else if (current == "-") {
      rotate(-angle);
    } else if (current == "[") {
      push();
    } else if (current == "]") {
      pop();
    }
  }
}

function gotSpeech() {
  if (speechRec.resultValue) {
    userSpeech = speechRec.resultString;
    getWordsLen(userSpeech);
    sentenceArray.push(userSpeech);
    console.log("You said:", userSpeech);
  }
}

function getWordsLen(userIn){
  let num = userIn.trim().split(/\s+/).length;
  let genNum = 0;
  if (num < 5) {
    genNum = 1;
  } else if (num >= 5 && num < 10) {
    genNum = 2;
  } else {
    genNum = 3;
  }
  generateMultiple(genNum);
}


